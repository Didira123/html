{    
    var nascimento = window.prompt("Ano de Nascimento: ");
    var anoAtual = new Date().getFullYear();
    window.alert(anoAtual - nascimento);
}