
var num1 = parseInt(window.prompt("1º valor: "));
var num2 = parseInt(window.prompt("2º valor: "));
window.alert(num1+num2);

