
var nums = window.prompt(`Diga 3 números, separados por um espaço, cada um: `).split(" ");
window.alert(`O maior número dentre os informados é: ${Math.max(parseFloat(nums[0]), parseFloat(nums[1]), parseFloat(nums[2]))}`);


